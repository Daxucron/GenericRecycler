package com.example.campodetiro.ui.home.recycler;

import android.widget.TextView;

public abstract class Item{
    private String text;
    // Método que verifica si el ítem es expandible usando instanceof
    public boolean isExpandable() {
        return this instanceof Expandable;
    }

    public String getText() {
        return text;
    }
    public void setText(String text) {
        this.text = text;
    }
}
