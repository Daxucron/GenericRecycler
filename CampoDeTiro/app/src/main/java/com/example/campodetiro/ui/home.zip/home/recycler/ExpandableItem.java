package com.example.campodetiro.ui.home.recycler;

import java.util.List;

public class ExpandableItem extends Item implements Expandable<Item>{

    private List<Item> childItems;
    private boolean expanded;

    public ExpandableItem(String title, List<Item> childItems) {
        setText(title);
        this.childItems = childItems;
    }



    @Override
    public List<Item> getListChildItems() {
        return childItems;
    }

    @Override
    public boolean isExpanded()
    {
        return expanded;
    }

    @Override
    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }


}
