package com.example.campodetiro.ui.home.recycler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campodetiro.R;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
{
    private static final int VIEW_TYPE_SIMPLE = 0;
    private static final int VIEW_TYPE_EXPANDABLE = 1;
    private List<Item> items;
    private LayoutInflater inflater;

    public RecyclerViewAdapter(Context context, List<Item> items) {
        this.items = items;
        this.inflater = LayoutInflater.from(context);
    }

    // Determina el tipo de vista (simple o expandible) según el ítem en la posición
    @Override
    public int getItemViewType(int position) {
        if (items.get(position).isExpandable()) {
            return VIEW_TYPE_EXPANDABLE;
        } else {
            return VIEW_TYPE_SIMPLE;
        }
    }

    // Crea el ViewHolder adecuado según el tipo de ítem (simple o expandible)
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_SIMPLE) {
            View view = inflater.inflate(R.layout.item_simple, parent, false);
            return new SimpleViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_expandable, parent, false);
            return new ExpandableViewHolder(view);
        }
    }

    // Vincula los datos con el ViewHolder según la posición y el tipo de ítem
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Item item = items.get(position);

        if (holder instanceof SimpleViewHolder) {
            ((SimpleViewHolder) holder).simpleItemText.setText(((SimpleItem) item).getText());
        } else if (holder instanceof ExpandableViewHolder) {
            ExpandableViewHolder expandableHolder = (ExpandableViewHolder) holder;
            ExpandableItem expandableItem = (ExpandableItem) item;

            // TODO: Cambiar itemTitle a private y acceder por el método
            expandableHolder.itemTitle.setText(expandableItem.getText());
            setupChildRecyclerView(expandableHolder.recyclerView, expandableItem.getListChildItems());

            if (expandableItem.isExpanded()) {
                expandableHolder.expandableContent.setVisibility(View.VISIBLE);
            } else {
                expandableHolder.expandableContent.setVisibility(View.GONE);
            }

            expandableHolder.itemView.setOnClickListener(v -> {
                expandableItem.setExpanded(!expandableItem.isExpanded());
                notifyItemChanged(position);
            });
        }
    }

    private void setupChildRecyclerView(RecyclerView recyclerView, List<Item> childItems) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(recyclerView.getContext());
        recyclerView.setLayoutManager(layoutManager);

        // Reutilizamos el mismo adaptador para los ítems hijos
        RecyclerViewAdapter childAdapter = new RecyclerViewAdapter(recyclerView.getContext(), childItems);
        recyclerView.setAdapter(childAdapter);
    }

    // Retorna la cantidad total de ítems en la lista
    @Override
    public int getItemCount() {
        return items.size();
    }
}