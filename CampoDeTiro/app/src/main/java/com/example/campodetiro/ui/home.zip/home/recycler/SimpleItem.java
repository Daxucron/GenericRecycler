package com.example.campodetiro.ui.home.recycler;

public class SimpleItem extends Item{

    public SimpleItem(String text) {
        setText(text);
    }
}
